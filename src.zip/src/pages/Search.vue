<template>
   <div>
      <iframe src="/public/page.html" scrolling="auto" frameborder="0" style="width: 100%;height: 900px;"></iframe>
    </div>
</template>

<script>
export default {
    name:"Search",
    data(){
      return{
        showSessionId:'',
        src:'',
      };
    },
    mounted(){
      this.showSessionId=window.location.Search;
      this.src='../../public/page.html';
    },
}
</script>

