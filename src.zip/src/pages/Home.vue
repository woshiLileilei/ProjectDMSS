<template>
  <div>
    欢迎来到Home页面
  </div>
</template>

<script>
export default {
    name:"Home"
}
</script>
