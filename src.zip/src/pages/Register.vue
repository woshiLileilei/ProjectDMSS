<template>
  <div>
    欢迎来到Register页面
  </div>
</template>

<script>
export default {
    name:"Register"
}
</script>
