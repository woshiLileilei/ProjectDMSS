import Vue from "vue";
import VueRouter from "vue-router";

import Home from "@/pages/Home.vue";
import Search from "@/pages/Search.vue";
import Login from "@/pages/Login.vue";
import Register from "@/pages/Register.vue";


Vue.use(VueRouter);

export default new VueRouter({
    routes:[
        {
            path:"/home",
            component:Home
        },
        {
            path:"/search",
            component:Search
        },
        {
            path:"/login",
            component:Login
        },
        {
            path:"/register",
            component:Register
        },
        {
            path:"/",
            redirect:"/home"
        }
    ]
})
