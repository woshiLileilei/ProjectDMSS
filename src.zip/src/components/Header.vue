<template>
  <div>
    我是Header组件
  </div>
</template>

<script>
export default {
    name:"Header"
}
</script>
